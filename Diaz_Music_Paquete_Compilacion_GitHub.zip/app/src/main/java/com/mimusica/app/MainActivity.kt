package com.mimusica.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.lifecycle.lifecycleScope
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.launch

data class Track(val name: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startForegroundService(Intent(this, PlaybackService::class.java))
        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ controller = future.get() }, MoreExecutors.directExecutor())

        setContent {
            var tracks by remember { mutableStateOf(listOf<Track>()) }
            var current by remember { mutableStateOf("Elige música de tu dispositivo") }
            var query by remember { mutableStateOf("") }
            val picker = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenMultipleDocuments()
            ) { uris ->
                val added = uris.map { uri ->
                    runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    Track(uri.lastPathSegment?.substringAfterLast('/') ?: "Audio", uri)
                }
                tracks = (tracks + added).distinctBy { it.uri }
            }

            MaterialTheme(colorScheme = darkColorScheme()) {
                Scaffold { padding ->
                    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                        Text("Díaz Music", style = MaterialTheme.typography.headlineLarge)
                        Text("Tu música, a tu manera", color = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.height(18.dp))
                        OutlinedTextField(
                            value = query, onValueChange = { query = it },
                            label = { Text("Buscar en tu biblioteca") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { picker.launch(arrayOf("audio/*")) }) {
                            Text("Añadir música del móvil")
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("Mi biblioteca", style = MaterialTheme.typography.titleLarge)
                        LazyColumn(Modifier.weight(1f)) {
                            items(tracks.filter { it.name.contains(query, ignoreCase = true) }) { track ->
                                ListItem(
                                    headlineContent = { Text(track.name) },
                                    supportingContent = { Text("Audio del dispositivo") },
                                    trailingContent = {
                                        TextButton(onClick = {
                                            current = track.name
                                            controller?.setMediaItem(MediaItem.fromUri(track.uri))
                                            controller?.prepare()
                                            controller?.play()
                                        }) { Text("Reproducir") }
                                    }
                                )
                                HorizontalDivider()
                            }
                        }
                        Text("Sonando: $current", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(onClick = { controller?.play() }) { Text("▶") }
                            OutlinedButton(onClick = { controller?.pause() }) { Text("Pausa") }
                            OutlinedButton(onClick = { controller?.seekToNextMediaItem() }) { Text("Siguiente") }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Reproduce archivos de audio de tu dispositivo. La reproducción puede continuar con la pantalla bloqueada.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        controller?.release()
        super.onDestroy()
    }
}
